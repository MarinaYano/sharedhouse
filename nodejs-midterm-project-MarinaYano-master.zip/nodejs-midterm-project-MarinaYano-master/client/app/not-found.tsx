import { Button } from "@/components/ui/button"
import Link from "next/link"

const NotFound = () => {
  return (
    <div className="container mx-auto text-center py-20">
      <h2>Not Found</h2>
      <p>Sorry, the page you are looking for does not exist.</p>
      <Button variant="link" className="hover:underline-offset-4">
        <Link href="/">Return Home</Link>
      </Button>
    </div>
  )
}

export default NotFound