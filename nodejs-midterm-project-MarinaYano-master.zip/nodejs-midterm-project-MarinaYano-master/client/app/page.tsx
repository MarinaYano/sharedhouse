import PostList from "../components/PostList";

export default function Home() {

  return (
    <div className="container mx-auto mt-20 mb-10">
      <PostList />
    </div>
  );
}
