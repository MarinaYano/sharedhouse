import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import React from 'react'

const page = () => {
  return (
    <div className='container mx-auto mt-20 mb-10'>
      <form className='space-y-2 w-full mx-auto'>
        <Input type='text' placeholder='title' />
        <Input type='number' placeholder='rent' />
        <Input type='text' placeholder='area' />
        <Input type='text' placeholder='station' />
        <Input type='text' placeholder='type of room' />
        <Textarea placeholder='description' />
        <Button
          variant="blue"
          type='submit'
        >
          Submit
        </Button>
      </form>
    </div>
  )
}

export default page