'use client';
import PostCard from "@/components/PostCard";
import { Post } from "@/components/PostList";
import EditModal from "@/components/modals/EditModal";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import useEditModal from "@/components/zustand/useEditModal";
import axios from "axios";
import Link from "next/link";
import { useEffect, useState } from "react";

const page = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [username, setUsername] = useState<string>('');
  const { toast } = useToast();
  const editModal = useEditModal();

  useEffect(() => {
    fetchUserData();
  }, []);

  const fetchUserData = async () => {
    try {
      const userRes = await axios.get("http://localhost:8005/api/users/checkLoggedIn", { withCredentials: true });
      const userData = await userRes.data;

      if (userData.loggedIn) {
        setUsername(userData.username);
        fetchUserPosts();
      } else {
        console.log('Error: ', userData.message);
      }
    } catch (error) {
      console.log('Error: ', error);
    }
  };

  const fetchUserPosts = async () => {
    try {
      const postRes = await axios.get("http://localhost:8005/api/users/userposts", { withCredentials: true });
      const postData = await postRes.data;
      setPosts(postData);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Something went wrong",
        description: "Please try again later",
      });
    }
  };

  const handleDelete = async (postId: number) => {
    try {
      await axios.delete(`http://localhost:8005/api/posts/${postId}`, { withCredentials: true });

      toast({
        title: "Successfully deleted a post",
      });
      setPosts(posts.filter((post) => post.id !== postId));
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Something went wrong",
        description: "Please try again later",
      })
    }
  }

  return (
    <>
      <div className="w-fit mx-auto mt-20 mb-10 px-4">
      <h3 className="pt-4">Profile: {username}</h3>
      <p className="text-sm text-slate-400 pb-4">You can see your listings</p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-8">
        {posts.map((post) => (
          <div key={post.id} className="col-span-1 space-y-1 cursor-pointer">
            <Link href={`/property/${post.id}`}>
              <PostCard post={post} />
            </Link>
            <div className="flex justify-between gap-2">
              <Button
                onClick={editModal.onOpen}
                className="w-full"
              >
                Edit this post
              </Button>
              <Button
                variant='destructive'
                onClick={() => handleDelete(post.id)}
                className="w-full"
              >
                Delete this post
              </Button>
              <EditModal post={post} />
            </div>
          </div>
        ))}
      </div>
    </div>
    </>
  );
};

export default page;