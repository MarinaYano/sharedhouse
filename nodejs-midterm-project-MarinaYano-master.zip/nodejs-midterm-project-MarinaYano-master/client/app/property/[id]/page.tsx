'use client'
import { Post } from '@/components/PostList'
import axios from 'axios'
import Image from 'next/image'
import { useParams } from 'next/navigation'
import { useEffect, useState } from 'react'
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel"
import { Input } from '@/components/ui/input'
import { RiMoneyDollarCircleLine } from "react-icons/ri";
import { FaTrain } from "react-icons/fa6";
import { BsFillCalendarDateFill } from "react-icons/bs";
import { IoBedSharp } from "react-icons/io5";
import { Textarea } from '@/components/ui/textarea'
import { Button } from '@/components/ui/button'

const page = () => {
  const { id } = useParams();
  const [post, setPost] = useState<Post>({
    id: 0,
    username: '',
    title: '',
    images: [],
    rent: 0,
    area: '',
    station: '',
    availableFrom: '',
    typeOfRoom: '',
    minimumStay: 0,
    description: ''
  })

  useEffect(() => {
    const getPostById = async () => {
      const res = await axios.get(`http://localhost:8005/api/posts/${id}`)
      const data = await res.data
      setPost(data)
    }

    getPostById()
  }, [])

  return (
    <div className='max-w-sm md:max-w-xl lg:max-w-3xl mx-auto mt-20 mb-10 px-4'>
      <div className='flex flex-col md:flex-raw justify-between'>
        <div>
          <h1 className='text-2xl font-semibold py-4'>{post.title}</h1>
          {/* delete button */}
        </div>
        <div className='grid grid-cols-2 md:grid-cols-4 gap-2 text-slate-800/80 mb-4'>
          <div className='flex items-center gap-x-1.5'>
            <RiMoneyDollarCircleLine className='text-lg' />
            <p>${post.rent}</p>
          </div>
          <div className='flex items-center gap-x-1.5'>
            <FaTrain />
            <p>{post.station}</p>
          </div>
          <div className='flex items-center gap-x-1.5'>
            <IoBedSharp />
            <p>{post.typeOfRoom}</p>
          </div>
          <div className='flex items-center gap-x-1.5'>
            <BsFillCalendarDateFill />
            <p>{post.availableFrom}</p>
          </div>
        </div>
      </div>
      <Carousel className='relative flex justify-center items-center'>
        <CarouselContent>
          {post.images.map((image, index) => (
            <CarouselItem key={index} className=''>
              <Image 
                src={image}
                alt='post image'
                width={400}
                height={300}
                className='rounded-xl w-full mx-auto' />
            </CarouselItem>
          ))}
        </CarouselContent>
        {post.images.length > 1 && (
          <>
            <CarouselPrevious className='absolute top-1/2 left-4' />
            <CarouselNext className='absolute top-1/2 right-2' />
          </>
        )}
      </Carousel>
      
      <div className='w-full'>
        <div className='my-5'>
          <p className='text-slate-400'>Posted by {post.username}</p>
          <p className='max-w-2xl border-t border-slate-300 py-5 mt-5'>{post.description}</p>
        </div>
        {/* <div className='fixed bottom-0 left-0 md:relative md:my-4 md:mx-4 bg-white w-full'>
          <form action="" className='py-4 px-2 shadow-lg rounded-md md:max-w-96'>
            <h3 className='text-lg font-medium py-4 mx-4'>Contact Form</h3>
            <div className='hidden md:block space-y-4'>
              <Input type='text' placeholder='Name*' />
              <Input type='email' placeholder='Email*' />
              <Input type='tel' placeholder='Phone' />
              <Textarea placeholder='Message*' />
              <Button variant='blue' type='submit'>Submit</Button>
            </div>
          </form>
        </div> */}
      </div>

    </div>
  )
}

export default page