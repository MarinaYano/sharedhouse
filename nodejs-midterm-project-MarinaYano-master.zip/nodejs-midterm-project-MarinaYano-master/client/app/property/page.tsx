

export const page = () => {
  return (
    <div>page</div>
  )
}
