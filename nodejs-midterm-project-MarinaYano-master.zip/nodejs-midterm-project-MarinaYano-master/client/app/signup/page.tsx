'use client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import axios from 'axios'
import { useRouter } from 'next/navigation'
import { FormEvent, useState } from 'react'
import { useToast } from "@/components/ui/use-toast"


const page = () => {
  const [username, setUsername] = useState<string>('')
  const [password, setPassword] = useState<string>('')
  const router = useRouter();
  const { toast } = useToast()

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
   try {
    await axios.post("http://localhost:8005/api/users/signup",
    { username, password },
    { withCredentials: true }
    );

    toast({
      description: "You have successfully signed up",
    })
    router.push('/')
   } catch (error) {
    console.log(error)
    toast({
      variant: "destructive",
      title: "Something went wrong",
      description: "Please try again later",
    })
   }
  }

  return (
    <div className='container mx-auto mt-20 mb-10'>
      <form onSubmit={(e) => handleSubmit(e)} className='w-72 mx-auto'>
        <h3 className='text-lg font-medium text-center py-6'>Signup</h3>
        <div className='w-72 mx-auto flex flex-col items-center gap-y-3'>
          <Input
            type='text'
            placeholder='Username'
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            />
          <Input
            type='password'
            placeholder='Password'
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            />
          <Button variant='blue' type='submit'>Submit</Button>
        </div>
      </form>
    </div>
  )
}

export default page