import React from 'react'

const Footer = () => {
  return (
    <div className='container mx-auto py-4'>
      <p className='text-slate-600 text-center text-sm'>All rights reserved &copy; 2024</p>
    </div>
  )
}

export default Footer