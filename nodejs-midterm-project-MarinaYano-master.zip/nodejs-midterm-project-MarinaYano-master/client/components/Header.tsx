'use client'
import { FaHouseChimney } from "react-icons/fa6";
import { IoMenu } from "react-icons/io5";
import { Input } from "./ui/input";
import { IoSearch } from "react-icons/io5";
import { IoCreate } from "react-icons/io5";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import axios from "axios";
import { useToast } from "./ui/use-toast";
import usePostModal from "./zustand/usePostModal";


const Header = () => {
  const [loggedIn, setLoggedIn] = useState<boolean>(false)
  const [username, setUsername] = useState<string>('')
  const { toast } = useToast();
  const postModal = usePostModal();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const res = await axios.get("http://localhost:8005/api/users/checkLoggedIn", { withCredentials: true });
        const data = await res.data;

        if(data.loggedIn) {
          setLoggedIn(true)
          setUsername(data.username)
        } else {
          console.log('Error: ', data.message)
        }

      } catch (error) {
        console.log('Error: ', error)
      }
    }

    checkAuth()
  }, [])

  const handleLogout = async () => {
    try {
      const res = await axios.get("http://localhost:8005/api/users/logout", { withCredentials: true });
      const data = await res.data;
      console.log(data)
      setLoggedIn(data.loggedIn)
      setUsername(data.username)
      toast({
        title: "Successfully Logged out"
      })
    } catch (error) {
      console.log(error)
    }
  }

  return (
    <div className='max-w-sm md:max-w-lg lg:container mx-auto'>
      <div className="w-full py-4 px-4 fixed top-0 left-0 flex justify-between items-center bg-white z-50 shadow">
        <Link href='/'>
          <div className="flex gap-3">
            <FaHouseChimney className="text-2xl text-blue-800" />
            <p className="text-blue-800 font-semibold">SharedHouse.com</p>
          </div>
        </Link>
        <div className="relative hidden md:block">
          <Input className="w-72" />
          <button className="absolute top-2.5 right-3">
            <IoSearch className="text-xl" />
          </button>
        </div>
        <div className="flex items-center gap-4">
          {loggedIn && (
            <button onClick={postModal.onOpen}>
              <IoCreate className="text-2xl hover:text-primary/80" />
            </button>
            
          )}
          <DropdownMenu>
            <DropdownMenuTrigger><IoMenu className="text-2xl hover:text-primary/80" /></DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuLabel>{username ? username : "Guest"}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {loggedIn ? (
                <>
                  <Link href='/profile'><DropdownMenuItem>Profile</DropdownMenuItem></Link>
                  <DropdownMenuItem onClick={handleLogout}>Logout</DropdownMenuItem>
                </>
              ) : (
                <>
                  <Link href='/signup'><DropdownMenuItem>Sign Up</DropdownMenuItem></Link>
                  <Link href='/login'><DropdownMenuItem>Login</DropdownMenuItem></Link>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  )
}

export default Header