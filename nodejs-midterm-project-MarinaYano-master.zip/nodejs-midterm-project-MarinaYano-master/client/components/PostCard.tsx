import { Post } from "./PostList"
import Image from "next/image"

type PostCardProps = {
  post: Post
}

const PostCard = ({ post }: PostCardProps) => {
  return (
    <>
      <Image
        src={post.images[0]}
        alt='post image'
        width={350}
        height={350}
        style={{ width: '100%', height: 'auto' }}
        sizes="(min-width: 640px) 33vw, (min-width: 768px) 25vw"
        className='rounded-xl'
      />
      <h3 className="truncate max-w-80 my-2">{post.title}</h3>
      <div className="flex justify-between max-w-80">
        <div className="text-gray-400 text-sm font-light">{post.area}</div>
        <div className="text-gray-400 text-sm max-w-40 truncate font-light">{post.station}</div>
      </div>
      <div className="flex justify-between items-center my-0.5 max-w-80">
        <h3 className="font-medium">${post.rent}</h3>
        <p className="text-gray-800 font-light text-sm">{post.typeOfRoom}</p>
      </div>
    </>
  )
}

export default PostCard