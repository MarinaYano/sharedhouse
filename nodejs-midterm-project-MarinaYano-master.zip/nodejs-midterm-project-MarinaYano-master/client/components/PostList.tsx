'use client'
import axios from "axios";
import { useEffect, useState } from "react";
import PostCard from "./PostCard";
import Link from "next/link";

export type Post = {
  id: number;
  username: string;
  title: string;
  images: string[];
  rent: number;
  area: string;
  station: string;
  availableFrom: string;
  typeOfRoom: string;
  minimumStay: number;
  description: string;
}

const PostList = () => {
  const [posts, setPosts] = useState<Post[]>([])
  
  useEffect(() => {
    const getAllPosts = async () => {
      const res = await axios.get("http://localhost:8005/api/posts")
      const data = await res.data
      setPosts(data)
    }

    getAllPosts()
  } , [])

  return (
    <div className="w-fit mx-auto">
      <h2 className="py-4 text-lg font-medium">Listings</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {posts.map((post) => (
          <div key={post.id} className="col-span-1 space-y-1 cursor-pointer">
            <Link href={`/property/${post.id}`}>
              <PostCard post={post} />
            </Link>
          </div>
        ))}
      </div>
    </div>
  )
}

export default PostList