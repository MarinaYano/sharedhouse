'use client'

type AreaInputProps = {
  label: string,
  selected?: boolean,
  onClick: (value: string) => void,
}

const AreaInput = ({
  label,
  selected,
  onClick,
}: AreaInputProps) => {
  return (
    <div
     onClick={() => onClick(label)}
     className={`rounded-md border-2 p-4 hover:border-slate-800 transition cursor-pointer
      ${ selected ? 'border-slate-800' : 'border-slate-200' }
    `}
    >
      <div className="font-semibold">
        {label}
      </div>
    </div>
  )
}

export default AreaInput