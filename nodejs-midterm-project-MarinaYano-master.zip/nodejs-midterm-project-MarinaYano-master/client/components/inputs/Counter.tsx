'use client'

import { useCallback } from "react";
import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";

type CounterProps = {
  title: string;
  subtitle: string;
  value: number;
  onChange: (value: number) => void;
}

const Counter = ({
  title,
  subtitle,
  value,
  onChange
}: CounterProps) => {
  const onAdd = useCallback(() => {
    onChange(value + 1);
  }, [onChange, value])

  const onReduce = useCallback(() => {
    onChange(value - 1);
  }, [onChange, value]);

  return (
    <div className="flex items-center justify-between">
      <div className="flex flex-col">
        <h3 className="font-medium">{title}</h3>
        <p className="text-slate-400">{subtitle}</p>
      </div>
      <div className="flex items-center gap-4">
        <button onClick={onReduce} className="w-10 h-10 rounded-full border border-slate-400 text-slate-400 flex justify-center items-center cursor-pointer hover:opacity-80 transition">
          <AiOutlineMinus />
        </button>
        <span className="font-light text-lg text-slate-400">
          {value}
        </span>
        <button onClick={onAdd} className="w-10 h-10 rounded-full border border-slate-400 text-slate-400 flex justify-center items-center cursor-pointer hover:opacity-80 transition">
          <AiOutlinePlus />
        </button>

      </div>
    </div>
  )
}

export default Counter