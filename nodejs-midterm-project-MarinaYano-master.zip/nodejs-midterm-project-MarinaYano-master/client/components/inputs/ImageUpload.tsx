'use client'

import { CldUploadWidget } from 'next-cloudinary';
import Image from 'next/image';
import { useCallback } from 'react';
import { TbPhotoPlus } from 'react-icons/tb';

declare global {
  var cloudinary: any;
}

type ImageUploadProps = {
  onChange: (value: string) => void;
  value: string;
}

const ImageUpload = ({
  onChange,
  value
}: ImageUploadProps) => {
  const handleUpload = useCallback((result: any) => {
    onChange(result.info.secure_url)
  }, [])

  return (
    <div>
      <CldUploadWidget
        onUpload={handleUpload}
        uploadPreset='node-midterm'
        options={{
          maxFiles: 1,
        }}
        >
          {({ open }) => {
            return (
              <div
                onClick={() => open?.()}
                className='relative cursor-pointer hover:opacity-80 transition border-dashed border-2 p-20 border-slate-400 flex flex-col justify-center items-center gap-4 text-slate-600'
                >
                  <TbPhotoPlus size={50} />
                  <div className='font-medium text-lg'>Click to upload</div>
                  { value && (
                    <div className='absolute inset-0 w-full h-full'>
                      <Image
                        src={value}
                        alt='Uploaded image'
                        fill
                        style={{ objectFit: 'cover' }}
                        // width={300}
                        // height={200}
                        layout='fixed'
                        />
                    </div>
                  )}
              </div>
            )
          }}
        </CldUploadWidget>
    </div>
  )
}

export default ImageUpload