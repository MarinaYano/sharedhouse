'use client'

import useEditModal from "../zustand/useEditModal"
import { FieldValues, SubmitHandler, useForm } from "react-hook-form";
import { useEffect, useMemo, useState } from "react";
import axios from "axios";

import { areas } from "../../lib/areas";
import { stations } from "../../lib/stations";
import { typeOfRooms  } from "@/lib/typeOfRooms";

import Modal from "./Modal"
import Heading from "./Heading";
import AreaInput from "../inputs/AreaInput";
import Input from "../inputs/Input";
import Counter from "../inputs/Counter";
import ImageUpload from "../inputs/ImageUpload";

import { useToast } from "../ui/use-toast";
import { Calendar } from "@/components/ui/calendar"

import { useRouter } from "next/router";
import { Post } from "../PostList";

type EditModalProps = {
  post: Post;
}

enum STEPS {
  TEXTINFO = 0, // title, description
  LOCATION = 1, // area, station
  IMAGES = 2, //images
  NUMBER = 3, //rent, minimum stay
  DATE = 4,
  ROOM = 5,
}

const EditModal = ({ post }: EditModalProps) => {
  const editModal = useEditModal();
  // const router = useRouter();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [step, setStep] = useState<STEPS>(STEPS.TEXTINFO);
  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
    reset
  } = useForm<FieldValues>({
    defaultValues: post || {
      title: '',
      description: '',
      area: '',
      station: '',
      rent: 0,
      minimumStay: 0,
      availableFrom: '',
      typeOfRoom: '',
    }
  });

  useEffect(() => {

  }, [])

  const area = watch('area');
  const station = watch('station');
  const typeOfRoom = watch('typeOfRoom');
  const date = watch('availableFrom');

  const setCustomValue = (id: string, value: any) => {
    setValue(id, value, {
      shouldValidate: true,
      shouldDirty: true,
      shouldTouch: true
    });

  }

  const onNext = () => {
    setStep((value) => value + 1);
  }

  const onBack = () => {
    setStep((value) => value - 1);
  }

  const actionLabel = useMemo(() => {
    if(step === STEPS.ROOM) {
      return "Create"
    }

    return 'Next';
  }, [step]);

  const onSubmit: SubmitHandler<FieldValues> = async (data) => {
    if(step !== STEPS.ROOM) return onNext();

    setIsLoading(true);

    axios.put(`http://localhost:8005/api/posts/${post.id}`, data, { withCredentials: true })
    .then(() => {
      toast({
        title: "Successfully updated a post",
      })

      editModal.onClose();
      // router.push('/');
      reset();
      setStep(STEPS.TEXTINFO);
      editModal.onClose();
    })
    .catch(() => {
      toast({
        variant: "destructive",
        title: "Something went wrong",
        description: "Please try again later",
      })
    })
    .finally(() => {
      setIsLoading(false);
    })
  }

  const secondaryActionLabel = useMemo(() => {
    if(step === STEPS.TEXTINFO) {
      return undefined;
    }

    return 'Back';
  }, [step])

  let bodyContent = (
    <div className="space-y-4">
      <Heading
        title="Property Listing"
        subtitle="How would you describe your property?"
      />
      <Input
        id='title'
        label='Title'
        disabled={isLoading}
        register={register}
        errors={errors}
        required
      />
      <Input
        id='description'
        label='Description'
        disabled={isLoading}
        register={register}
        errors={errors}
        required
      />
    </div>
  )

  if(step === STEPS.LOCATION) {
    bodyContent= (
      <div className="space-y-4">
        <Heading
          title='Choose your location'
          subtitle='Select the area and the nearest station'
        />
      <h3 className="text-lg font-medium">Area</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-48 overflow-y-auto">
          {areas.map((item) => (
            <div key={item.id} className="col-span-1">
              <AreaInput
                onClick={(value) => setCustomValue('area', value)}
                selected={area === item.label}
                label={item.label}
              />
            </div>
          ))}
       </div>
      <h3 className="text-lg font-medium">Station</h3>
       <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-48 overflow-y-auto">
          {stations.map((item) => (
            <div key={item} className="col-span-1">
              <AreaInput
                onClick={(value) => setCustomValue('station', value)}
                selected={station === item}
                label={item}
              />
            </div>
          ))}
       </div>
      
      </div>
    )
  }

  if(step === STEPS.IMAGES) {
    bodyContent = (
      <div className="space-y-4">
        <Heading
          title='Add a photo of your property'
          subtitle='Choose the best images of your property'
        />
        <ImageUpload
          value={watch('images')}
          onChange={(value) => setCustomValue('images', value)}
        />
      </div>
    )
  }

  if(step === STEPS.NUMBER) {
    bodyContent = (
      <div className="space-y-4">
        <Heading
          title='Rent and minimum stay'
          subtitle='Set the rent and the minimum stay'
        />
        <Input
          id='rent'
          label='Rent'
          type='number'
          formatPrice
          disabled={isLoading}
          register={register}
          errors={errors}
          required
        />
        <Counter
          title="Minimum stay"
          subtitle="Minimum stay in months"
          value={watch('minimumStay')}
          onChange={(value) => setCustomValue('minimumStay', value)}
        />
      </div>
    )
  }

  if(step === STEPS.DATE) {
    bodyContent = (
      <div className="space-y-4">
        <Heading
          title='Available from'
          subtitle='Set the date when the property is available'
        />
        <Calendar
          mode="single"
          selected={date}
          onSelect={(value) => setCustomValue('availableFrom', value)}
          className="rounded-md border"
        />
      </div>
    )
  }

  if(step === STEPS.ROOM) {
    bodyContent = (
      <div className="space-y-4">
        <Heading
          title="Type of room"
          subtitle="Choose the type of room"
        />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-48 overflow-y-auto">
          {typeOfRooms.map((item) => (
            <div key={item} className="col-span-1">
              <AreaInput
                onClick={(value) => setCustomValue('typeOfRoom', value)}
                selected={typeOfRoom === item}
                label={item}
              />
            </div>
          ))}
       </div>
      </div>
    )
  }

  return (
    <div>
      <Modal
        isOpen={editModal.isOpen}
        onClose={editModal.onClose}
        onSubmit={handleSubmit(onSubmit)}
        actionLabel={actionLabel}
        secondaryActionLabel={secondaryActionLabel}
        secondaryAction={step === STEPS.TEXTINFO ? undefined : onBack}
        title="Post Your Property"
        body={bodyContent}
      />
    </div>
  )
}

export default EditModal