'use client'

type HeadingProps = {
  title: string,
  subtitle?: string,
  center?: boolean,
}

const Heading = ({
  title,
  subtitle,
  center
}: HeadingProps) => {
  return (
    <div className={`${ center ? 'text-center' : 'text-start' }`}>
      <h3 className="text-xl font-semibold">{title}</h3>
      <p className="font-light text-slate-400 mt-2">{subtitle}</p>
    </div>
  )
}

export default Heading