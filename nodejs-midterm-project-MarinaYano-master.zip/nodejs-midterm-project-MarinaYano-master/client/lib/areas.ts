export const areas = [
  {
    id: 1,
    label: 'Downtown',
  },
  {
    id: 2,
    label: 'Kitsulano',
  },
  {
    id: 3,
    label: 'South Vancouver',
  },
  {
    id: 4,
    label: 'Burnaby',
  },
  {
    id: 5,
    label: 'North Burnaby',
  },
  {
    id: 6,
    label: 'Richmond',
  },
  {
    id: 7,
    label: 'Surrey',
  },
  {
    id: 8,
    label: 'New Westminster',
  },
  {
    id: 9,
    label: 'Coquitlam',
  },
  {
    id: 10,
    label: 'Port Coquitlam',
  },
  {
    id: 11,
    label: 'Port Moody',
  },
  {
    id: 12,
    label: 'North Vancouver',
  },
  {
    id: 13,
    label: 'West Vancouver',
  },
  {
    id: 14,
    label: 'East Vancouver',
  },
  {
    id: 15,
    label: 'Westminster',
  },
  {
    id: 16,
    label: 'East Port Moody',
  },
  {
    id: 17,
    label: 'West Port Moody',
  },
  {
    id: 18,
    label: 'UBC',
  },
  {
    id: 19,
    label: 'Langara',
  },
]