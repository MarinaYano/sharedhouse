export const typeOfRooms = [
  'Private Room',
  'Shared Room',
  'Den',
  'Living Room',
  'Studio',
  'Solarium',
  'Private Suite',
  'Bachelor Suite',
]